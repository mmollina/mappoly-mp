int nChoosek(int n, int k);
std::vector <bool> get_boolean_vec_from_lexicographical_index(int ploidy, int index);
int n_rec_given_genk_and_k1(int ploidy, int index1, int index2);
double addlog(double a, double b);
double prob_k1_given_k_l_m(int m, int l, double rf);
double log_prob_k1_given_k_l_m(int m, int l, double rf);
std::vector<double> transition(int ploidy1, int ploidy2, std::vector<double>& rf);
std::vector<double> log_transition(int ploidy1, int ploidy2, std::vector<double>& rf);
std::vector<double> rec_num(int ploidy1, int ploidy2);
//end of file

